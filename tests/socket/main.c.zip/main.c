
#include <swilib.h>
#include <process.h>
#include <timer.h>
#include <coreevent.h>
#include <waitcondition.h>
#include <processbridge.h>
#include "socket.h"

/* WARNING 
 * В нерабочем состоянии.
 */


int main()
{
    initUsart();
    printf(" [+] main: pid: %d\n", pid());

    int fd = createSocket();
    int err, f = -1;
    if(fd < 0) {
        printf("failde to create socket id\n");
        return 0;
    }

    printf("Connecting ...\n");
    if(openSocketByHost(fd, "team-sc.ru", 80)) {
        printf("failed to open\n");
        goto err;
    }

    printf("Waiting ...\n");
    if(waitForSocketConnected(fd)) {
       printf("failed waiting for connection\n");
       goto err;
    }


    char data[1024*8] = "GET / HTTP/1.0\r\n"
                          "Host: team-sc.ru\r\n"
                          "User-Agent: Ololo\r\n"
                          "Connection: close\r\n\r\n";

    printf("Writing ...\n");
    if(writeSocket(fd, data, strlen(data))) {
        printf("failed to send data\n");
        goto err;
    }


    f = sync_open("4:\\elf\\coretest\\received.txt", A_Create | A_WriteOnly | A_BIN, P_WRITE, 0);
    if(f == -1)
        printf("failed to create file\n");

    while(1) {

        data[0] = 0;

        if(waitForSocketReadyRead(fd)) {
            printf("failed waiting for write finished\n");
            goto err;
        }

        printf("Reading ...\n");
        if(readSocket(fd, data, sizeof(data)-2)) {
            printf("failed to receive data\n");
            goto err;
        }

        printf("Waiting ...\n");
        if((err = waitForSocketReadFinished(fd))) {
            printf("failed waiting for read finished %d\n", err);
            goto err;
        }

        if(f != -1)
        {
            //printf("writting file ... \n");
            sync_write(f, data, strlen(data), 0);
            sync_close(f, 0);
            //printf(" done\n");
        }
    }


err:
    sync_close(f, 0);
    disconnectFromSocketHost(fd);
    waitForSocketDisconnected(fd);
    closeSocket(fd);
    ShowMSG(1, (int)"End");
    return 0;
}





